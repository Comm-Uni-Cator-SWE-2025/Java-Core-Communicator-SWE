/**
 * Entry point package for the Image Interpreter Spring Boot application.
 */
package com.swe.aiinsights.main;
