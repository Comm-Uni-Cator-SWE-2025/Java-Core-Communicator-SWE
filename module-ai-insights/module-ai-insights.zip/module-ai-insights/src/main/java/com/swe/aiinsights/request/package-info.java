/**
 * Defines request model classes for AI processing and image regularisation.
 */
package com.swe.aiinsights.request;
