/**
 * Contains file to create a singleton instance of AI.
 */
package com.swe.aiinsights.aiinstance;