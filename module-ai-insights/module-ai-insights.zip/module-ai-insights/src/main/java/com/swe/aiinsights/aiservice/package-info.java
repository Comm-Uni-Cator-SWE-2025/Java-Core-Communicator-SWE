/**
 * Provides AI service integration classes and interfaces.
 * This package defines communication with external LLM or AI backends.
 */
package com.swe.aiinsights.aiservice;
