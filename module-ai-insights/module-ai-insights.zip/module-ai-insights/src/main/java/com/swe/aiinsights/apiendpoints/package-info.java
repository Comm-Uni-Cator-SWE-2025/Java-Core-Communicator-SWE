/**
 * API endpoints for AI services.
 */

package com.swe.aiinsights.apiendpoints;
