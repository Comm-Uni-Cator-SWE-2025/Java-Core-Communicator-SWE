/**
 * Contains configurations for asynchronous event handling.
 */
package com.swe.aiinsights.configu;
