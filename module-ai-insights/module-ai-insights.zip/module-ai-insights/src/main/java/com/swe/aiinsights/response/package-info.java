/**
 * Defines response model classes for AI service outputs.
 */
package com.swe.aiinsights.response;
